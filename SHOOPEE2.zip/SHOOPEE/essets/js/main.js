function taikhoan() {
    var offtk = '<li class="header__nav-item"><a href="" class="header__nav-item-link header__nav-item-gach-2 "><b>Đăng ký</b> </a></li><li class="header__nav-item"><a href="" class="header__nav-item-link"> <b> Đăng nhập </b></a></li>';
    document.getElementById('info_login').innerHTML = offtk;
    //document.getElementById('dang_xuat').innerHTML=null;
}
